package com.ghostgrey.player

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private enum class Mode { DIRECT, PATCH }

    private var mode = Mode.DIRECT

    private lateinit var status: TextView
    private lateinit var playBtn: Button
    private lateinit var loadBtn: Button
    private lateinit var patchBtn: Button
    private lateinit var spinner: ProgressBar

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                if (mode == Mode.DIRECT) loadDirect(uri) else patchFrom(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#121212"))
        }

        root.addView(TextView(this).apply {
            text = "Pokémon Ghost Grey"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Fan-made ROM hack player.\nThis app contains no game. " +
                "Load your own Ghost Grey ROM file and play."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        })

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad / 2)
        }
        root.addView(status)

        spinner = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(spinner)

        playBtn = Button(this).apply {
            text = "Play"
            setOnClickListener { startActivity(Intent(this@MainActivity, GameActivity::class.java)) }
        }
        root.addView(playBtn)

        loadBtn = Button(this).apply {
            setOnClickListener {
                mode = Mode.DIRECT
                picker.launch(arrayOf("*/*"))
            }
        }
        root.addView(loadBtn)

        patchBtn = Button(this).apply {
            text = "Advanced: patch from a FireRed ROM"
            textSize = 12f
            setOnClickListener {
                mode = Mode.PATCH
                picker.launch(arrayOf("*/*"))
            }
        }
        root.addView(patchBtn)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ready = Patcher.romFile(this).exists()
        playBtn.visibility = if (ready) View.VISIBLE else View.GONE
        loadBtn.text = if (ready) "Load a different ROM" else "Load Ghost Grey ROM"
        status.text = if (ready) "Game is ready." else "Choose your Ghost Grey .gba file to begin."
    }

    private fun setBusy(busy: Boolean, msg: String? = null) {
        spinner.visibility = if (busy) View.VISIBLE else View.GONE
        loadBtn.isEnabled = !busy
        patchBtn.isEnabled = !busy
        playBtn.isEnabled = !busy
        if (msg != null) status.text = msg
    }

    private fun showError(title: String, msg: String?) {
        setBusy(false)
        refresh()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg ?: "Unknown error")
            .setPositiveButton("OK", null)
            .show()
    }

    // ---- Main path: the user already has the finished Ghost Grey ROM ----

    private fun loadDirect(uri: Uri) {
        setBusy(true, "Checking ROM…")
        Thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { Patcher.readLimited(it) }
                val crc = Patcher.crc32(bytes)
                val known = Patcher.isKnownHack(bytes, crc)
                val gba = Patcher.looksLikeGba(bytes)
                runOnUiThread {
                    when {
                        known -> installAsync(bytes)
                        !gba -> showError("Not a GBA ROM", "That file doesn't look like a Game Boy Advance ROM.")
                        else -> {
                            setBusy(false)
                            refresh()
                            AlertDialog.Builder(this)
                                .setTitle("Unrecognized version")
                                .setMessage(
                                    "This isn't a known Ghost Grey build (CRC32 ${Patcher.hex(crc)}).\n\n" +
                                        "It may be a different version. Try it anyway?"
                                )
                                .setPositiveButton("Try anyway") { _, _ -> installAsync(bytes) }
                                .setNegativeButton("Cancel", null)
                                .show()
                        }
                    }
                }
            } catch (e: Patcher.PatchException) {
                runOnUiThread { showError("Couldn't load", e.message) }
            } catch (e: Throwable) {
                runOnUiThread { showError("Couldn't load", "Something went wrong: ${e.message}") }
            }
        }.start()
    }

    private fun installAsync(bytes: ByteArray) {
        setBusy(true, "Loading…")
        Thread {
            val error: String? = try {
                Patcher.install(this, bytes)
                null
            } catch (e: Throwable) {
                e.message ?: "Couldn't save the game."
            }
            runOnUiThread {
                if (error != null) {
                    showError("Couldn't load", error)
                } else {
                    setBusy(false)
                    refresh()
                    status.text = "ROM loaded. Ready to play!"
                }
            }
        }.start()
    }

    // ---- Advanced path: patch from the player's own FireRed ROM ----

    private fun patchFrom(uri: Uri) {
        setBusy(true, "Patching… this takes a few seconds.")
        Thread {
            val error: String? = try {
                val base = contentResolver.openInputStream(uri)!!.use { Patcher.readLimited(it) }
                Patcher.buildGame(this, base)
                null
            } catch (e: Patcher.PatchException) {
                e.message
            } catch (e: Throwable) {
                "Something went wrong: ${e.message}"
            }
            runOnUiThread {
                if (error != null) {
                    showError("Couldn't patch", error)
                } else {
                    setBusy(false)
                    refresh()
                    status.text = "Patched and verified. Ready to play!"
                }
            }
        }.start()
    }
}
